"""
Professional Point-and-Click PDF Editor
Features: Add text, adjust font size/color, undo/redo, precise coordinate mapping
"""

import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk, colorchooser
from PIL import Image, ImageTk
import os
import json
from datetime import datetime

class PDFTextEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Professional PDF Editor - Point & Click Text Editor")
        self.root.geometry("1200x800")
        self.root.configure(bg="#2b2b2b")
        
        # Core data
        self.doc = None
        self.current_page = 0
        self.total_pages = 0
        self.zoom = 1.5
        self.edits = []  # Store all edits
        self.undo_stack = []  # For undo functionality
        self.redo_stack = []  # For redo functionality
        
        # Current edit settings
        self.font_size = tk.IntVar(value=12)
        self.font_color = "#000000"
        self.font_name = "helv"
        
        # Display properties
        self.page_pixmap = None
        self.display_image = None
        self.scale_factor = 1.0  # Ratio between canvas and actual PDF
        self.pdf_width = 0
        self.pdf_height = 0
        
        # Setup GUI
        self.setup_ui()
        
    def setup_ui(self):
        """Create the user interface"""
        # Top toolbar frame
        toolbar = tk.Frame(self.root, bg="#1e1e1e", height=60)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        toolbar.pack_propagate(False)
        
        # File operations section
        file_frame = tk.Frame(toolbar, bg="#1e1e1e")
        file_frame.pack(side=tk.LEFT, padx=10, pady=8)
        
        btn_open = tk.Button(file_frame, text="📂 Open PDF", command=self.open_pdf, 
                            bg="#4CAF50", fg="white", font=("Arial", 10, "bold"),
                            padx=15, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_open.pack(side=tk.LEFT, padx=5)
        
        btn_save = tk.Button(file_frame, text="💾 Save PDF", command=self.save_pdf,
                            bg="#2196F3", fg="white", font=("Arial", 10, "bold"),
                            padx=15, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_save.pack(side=tk.LEFT, padx=5)
        
        # Edit operations section
        edit_frame = tk.Frame(toolbar, bg="#1e1e1e")
        edit_frame.pack(side=tk.LEFT, padx=10, pady=8)
        
        btn_undo = tk.Button(edit_frame, text="↶ Undo", command=self.undo_edit,
                            bg="#FF9800", fg="white", font=("Arial", 10),
                            padx=12, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_undo.pack(side=tk.LEFT, padx=2)
        
        btn_redo = tk.Button(edit_frame, text="↷ Redo", command=self.redo_edit,
                            bg="#FF9800", fg="white", font=("Arial", 10),
                            padx=12, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_redo.pack(side=tk.LEFT, padx=2)
        
        btn_clear = tk.Button(edit_frame, text="🗑️ Clear All", command=self.clear_edits,
                             bg="#f44336", fg="white", font=("Arial", 10),
                             padx=12, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_clear.pack(side=tk.LEFT, padx=5)
        
        # Text formatting section
        format_frame = tk.Frame(toolbar, bg="#1e1e1e")
        format_frame.pack(side=tk.LEFT, padx=10, pady=8)
        
        tk.Label(format_frame, text="Size:", bg="#1e1e1e", fg="white", 
                font=("Arial", 9)).pack(side=tk.LEFT, padx=2)
        
        size_spinbox = tk.Spinbox(format_frame, from_=6, to=72, 
                                 textvariable=self.font_size, width=5,
                                 font=("Arial", 10), bg="#3c3c3c", fg="white",
                                 buttonbackground="#4CAF50")
        size_spinbox.pack(side=tk.LEFT, padx=5)
        
        btn_color = tk.Button(format_frame, text="🎨 Color", command=self.choose_color,
                             bg="#9C27B0", fg="white", font=("Arial", 10),
                             padx=10, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_color.pack(side=tk.LEFT, padx=5)
        
        self.color_preview = tk.Label(format_frame, text="  ", bg=self.font_color,
                                      width=3, relief=tk.SOLID, borderwidth=1)
        self.color_preview.pack(side=tk.LEFT, padx=2)
        
        # Font selector
        tk.Label(format_frame, text="Font:", bg="#1e1e1e", fg="white",
                font=("Arial", 9)).pack(side=tk.LEFT, padx=(10, 2))
        
        self.font_combo = ttk.Combobox(format_frame, width=10, 
                                      values=["helv", "times", "cour", "symb"],
                                      state="readonly")
        self.font_combo.set("helv")
        self.font_combo.pack(side=tk.LEFT, padx=2)
        self.font_combo.bind("<<ComboboxSelected>>", self.on_font_change)
        
        # Navigation section (right side)
        nav_frame = tk.Frame(toolbar, bg="#1e1e1e")
        nav_frame.pack(side=tk.RIGHT, padx=10, pady=8)
        
        btn_prev = tk.Button(nav_frame, text="◀ Prev", command=self.prev_page,
                            font=("Arial", 10), bg="#555", fg="white",
                            padx=10, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_prev.pack(side=tk.LEFT, padx=2)
        
        self.lbl_page = tk.Label(nav_frame, text="Page: 0 / 0", 
                                font=("Arial", 10, "bold"), bg="#1e1e1e", 
                                fg="white", width=15)
        self.lbl_page.pack(side=tk.LEFT, padx=10)
        
        btn_next = tk.Button(nav_frame, text="Next ▶", command=self.next_page,
                            font=("Arial", 10), bg="#555", fg="white",
                            padx=10, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_next.pack(side=tk.LEFT, padx=2)
        
        # Zoom controls
        zoom_frame = tk.Frame(toolbar, bg="#1e1e1e")
        zoom_frame.pack(side=tk.RIGHT, padx=10, pady=8)
        
        btn_zoom_out = tk.Button(zoom_frame, text="🔍−", command=self.zoom_out, 
                                font=("Arial", 12), bg="#666", fg="white",
                                padx=8, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_zoom_out.pack(side=tk.LEFT, padx=2)
        
        self.zoom_label = tk.Label(zoom_frame, text=f"{int(self.zoom*100)}%",
                                  font=("Arial", 10), bg="#1e1e1e", fg="white",
                                  width=6)
        self.zoom_label.pack(side=tk.LEFT, padx=5)
        
        btn_zoom_in = tk.Button(zoom_frame, text="🔍+", command=self.zoom_in, 
                               font=("Arial", 12), bg="#666", fg="white",
                               padx=8, pady=5, relief=tk.FLAT, cursor="hand2")
        btn_zoom_in.pack(side=tk.LEFT, padx=2)
        
        # Main canvas frame with scrollbars
        canvas_container = tk.Frame(self.root, bg="#2b2b2b")
        canvas_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create scrollbars
        v_scrollbar = tk.Scrollbar(canvas_container, orient=tk.VERTICAL)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        h_scrollbar = tk.Scrollbar(canvas_container, orient=tk.HORIZONTAL)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Canvas for PDF display
        self.canvas = tk.Canvas(canvas_container, bg="#3c3c3c", cursor="crosshair",
                               yscrollcommand=v_scrollbar.set,
                               xscrollcommand=h_scrollbar.set,
                               highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        v_scrollbar.config(command=self.canvas.yview)
        h_scrollbar.config(command=self.canvas.xview)
        
        # Bind events
        self.canvas.bind("<Button-1>", self.on_canvas_click)
        self.canvas.bind("<Configure>", self.on_resize)
        
        # Bottom status bar
        status_frame = tk.Frame(self.root, bg="#1e1e1e", height=30)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        status_frame.pack_propagate(False)
        
        self.status_var = tk.StringVar()
        self.status_var.set("📄 Open a PDF file to begin editing")
        status_bar = tk.Label(status_frame, textvariable=self.status_var, 
                             bg="#1e1e1e", fg="#aaa", anchor="w", padx=15,
                             font=("Arial", 9))
        status_bar.pack(fill=tk.BOTH, expand=True)
        
        # Instructions banner
        instructions = tk.Label(self.root, 
                               text="💡 INSTRUCTIONS: Click anywhere on the PDF to add text. "
                                    "Adjust font size and color before clicking. Use Undo/Redo to manage edits.",
                               bg="#FFF3CD", fg="#856404", font=("Arial", 9), 
                               pady=8, padx=10)
        instructions.pack(side=tk.BOTTOM, fill=tk.X)
    
    def choose_color(self):
        """Open color picker dialog"""
        color = colorchooser.askcolor(initialcolor=self.font_color, 
                                     title="Choose Text Color")
        if color[1]:  # color[1] is the hex value
            self.font_color = color[1]
            self.color_preview.config(bg=self.font_color)
            self.status_var.set(f"✓ Color changed to {self.font_color}")
    
    def on_font_change(self, event=None):
        """Update font name from combobox"""
        self.font_name = self.font_combo.get()
        self.status_var.set(f"✓ Font changed to {self.font_name}")
    
    def open_pdf(self):
        """Open a PDF file"""
        file_path = filedialog.askopenfilename(
            title="Select PDF File",
            filetypes=[("PDF Files", "*.pdf"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                # Close previous document if open
                if self.doc:
                    self.doc.close()
                
                # Open new PDF
                self.doc = fitz.open(file_path)
                self.current_page = 0
                self.total_pages = len(self.doc)
                self.edits = []
                self.undo_stack = []
                self.redo_stack = []
                
                self.status_var.set(f"📂 Loaded: {os.path.basename(file_path)} ({self.total_pages} pages)")
                self.update_page_display()
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open PDF:\n{str(e)}")
    
    def update_page_display(self):
        """Render the current page to the canvas"""
        if not self.doc:
            return
        
        try:
            # Get page and render to pixmap
            page = self.doc[self.current_page]
            mat = fitz.Matrix(self.zoom, self.zoom)
            self.page_pixmap = page.get_pixmap(matrix=mat, alpha=False)
            
            # Store PDF dimensions
            self.pdf_width = self.page_pixmap.width
            self.pdf_height = self.page_pixmap.height
            
            # Convert to PIL Image
            img_data = Image.frombytes("RGB", [self.pdf_width, self.pdf_height], 
                                      self.page_pixmap.samples)
            
            # Store the image
            self.display_image = img_data
            self.photo_image = ImageTk.PhotoImage(img_data)
            
            # Calculate scale factor (1:1 display)
            self.scale_factor = 1.0
            
            # Update canvas
            self.canvas.delete("all")
            self.canvas.create_image(0, 0, anchor=tk.NW, image=self.photo_image, tags="pdf")
            
            # Configure scroll region
            self.canvas.configure(scrollregion=(0, 0, self.pdf_width, self.pdf_height))
            
            # Redraw all edit markers for current page
            for edit in self.edits:
                if edit['page'] == self.current_page:
                    self.draw_edit_marker(edit)
            
            # Update page label and zoom label
            self.lbl_page.config(text=f"Page: {self.current_page + 1} / {self.total_pages}")
            self.zoom_label.config(text=f"{int(self.zoom*100)}%")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to render page:\n{str(e)}")
    
    def draw_edit_marker(self, edit):
        """Draw a marker showing where text will be added"""
        x_canvas = edit['x_canvas']
        y_canvas = edit['y_canvas']
        text = edit['text']
        color = edit.get('color', '#000000')
        
        # Draw marker circle
        marker_size = 6
        self.canvas.create_oval(x_canvas - marker_size, y_canvas - marker_size, 
                               x_canvas + marker_size, y_canvas + marker_size, 
                               outline="#FF4444", width=2, fill="#FF8888", 
                               tags="marker")
        
        # Draw text preview with background
        text_id = self.canvas.create_text(x_canvas, y_canvas, 
                                         text=text, fill=color, anchor=tk.W, 
                                         font=("Arial", int(edit['font_size'] * 0.75), "bold"),
                                         tags="marker")
        
        # Create background rectangle for text
        bbox = self.canvas.bbox(text_id)
        if bbox:
            self.canvas.create_rectangle(bbox[0]-2, bbox[1]-2, bbox[2]+2, bbox[3]+2,
                                        fill="#FFFFAA", outline="#FFAA00", width=1,
                                        tags="marker")
            self.canvas.tag_raise(text_id)
    
    def canvas_to_pdf_coords(self, x_canvas, y_canvas):
        """Convert canvas coordinates to PDF coordinates"""
        if not self.doc:
            return 0, 0
        
        # Get the actual page dimensions (before zoom)
        page = self.doc[self.current_page]
        page_rect = page.rect
        
        # Convert canvas coords to PDF coords accounting for zoom
        x_pdf = (x_canvas / self.zoom)
        y_pdf = (y_canvas / self.zoom)
        
        return x_pdf, y_pdf
    
    def on_canvas_click(self, event):
        """Handle mouse click on canvas"""
        if not self.doc:
            messagebox.showwarning("No PDF", "Please open a PDF file first!")
            return
        
        # Get click coordinates (canvas coordinates)
        x_canvas = self.canvas.canvasx(event.x)
        y_canvas = self.canvas.canvasy(event.y)
        
        # Show input dialog
        dialog = TextInputDialog(self.root, "Add Text", 
                                "Enter the text to add at this position:")
        new_text = dialog.result
        
        if new_text:  # If user entered text
            # Convert to PDF coordinates
            x_pdf, y_pdf = self.canvas_to_pdf_coords(x_canvas, y_canvas)
            
            # Store the edit with all coordinates
            edit = {
                'page': self.current_page,
                'x_canvas': x_canvas,
                'y_canvas': y_canvas,
                'x_pdf': x_pdf,
                'y_pdf': y_pdf,
                'text': new_text,
                'font_size': self.font_size.get(),
                'color': self.font_color,
                'font_name': self.font_name,
                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # Add to edits and undo stack
            self.edits.append(edit)
            self.undo_stack.append(('add', edit))
            self.redo_stack.clear()  # Clear redo stack on new action
            
            # Draw marker
            self.draw_edit_marker(edit)
            
            self.status_var.set(f"✓ Added text on page {self.current_page + 1}: '{new_text[:30]}...'")
    
    def undo_edit(self):
        """Undo the last edit"""
        if not self.undo_stack:
            messagebox.showinfo("Undo", "Nothing to undo!")
            return
        
        action, edit = self.undo_stack.pop()
        
        if action == 'add':
            self.edits.remove(edit)
            self.redo_stack.append(('add', edit))
        
        self.update_page_display()
        self.status_var.set(f"↶ Undone: {action} text")
    
    def redo_edit(self):
        """Redo the last undone edit"""
        if not self.redo_stack:
            messagebox.showinfo("Redo", "Nothing to redo!")
            return
        
        action, edit = self.redo_stack.pop()
        
        if action == 'add':
            self.edits.append(edit)
            self.undo_stack.append(('add', edit))
        
        self.update_page_display()
        self.status_var.set(f"↷ Redone: {action} text")
    
    def next_page(self):
        """Go to next page"""
        if self.doc and self.current_page < self.total_pages - 1:
            self.current_page += 1
            self.update_page_display()
    
    def prev_page(self):
        """Go to previous page"""
        if self.doc and self.current_page > 0:
            self.current_page -= 1
            self.update_page_display()
    
    def zoom_in(self):
        """Increase zoom level"""
        if self.doc:
            self.zoom = min(4.0, self.zoom + 0.25)
            self.update_page_display()
    
    def zoom_out(self):
        """Decrease zoom level"""
        if self.doc:
            self.zoom = max(0.5, self.zoom - 0.25)
            self.update_page_display()
    
    def clear_edits(self):
        """Clear all edits made"""
        if not self.edits:
            messagebox.showinfo("Clear", "No edits to clear!")
            return
            
        if messagebox.askyesno("Clear Edits", 
                              f"Are you sure you want to clear all {len(self.edits)} edits?"):
            self.edits = []
            self.undo_stack = []
            self.redo_stack = []
            self.update_page_display()
            self.status_var.set("🗑️ All edits cleared")
    
    def hex_to_rgb(self, hex_color):
        """Convert hex color to RGB tuple (0-1 range)"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) / 255.0 for i in (0, 2, 4))
    
    def save_pdf(self):
        """Save the PDF with all edits applied"""
        if not self.doc:
            messagebox.showwarning("No PDF", "No PDF file is open!")
            return
            
        if not self.edits:
            messagebox.showwarning("No Edits", "No edits to save!")
            return
        
        # Ask for save location
        save_path = filedialog.asksaveasfilename(
            title="Save Edited PDF",
            defaultextension=".pdf",
            filetypes=[("PDF Files", "*.pdf")],
            initialfile=f"edited_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        
        if save_path:
            try:
                # Create a copy of the document
                output_doc = fitz.open()
                output_doc.insert_pdf(self.doc)
                
                # Apply edits to each page
                for page_num in range(self.total_pages):
                    page_edits = [e for e in self.edits if e['page'] == page_num]
                    
                    if page_edits:
                        page = output_doc[page_num]
                        
                        for edit in page_edits:
                            # Get RGB color
                            rgb_color = self.hex_to_rgb(edit['color'])
                            
                            # Insert text at PDF coordinates
                            page.insert_text(
                                (edit['x_pdf'], edit['y_pdf']),
                                edit['text'],
                                fontsize=edit['font_size'],
                                fontname=edit['font_name'],
                                color=rgb_color
                            )
                
                # Save the document
                output_doc.save(save_path)
                output_doc.close()
                
                self.status_var.set(f"✅ PDF saved successfully: {os.path.basename(save_path)}")
                messagebox.showinfo("Success", 
                                  f"PDF saved successfully!\n\n"
                                  f"Location: {save_path}\n"
                                  f"Total edits applied: {len(self.edits)}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save PDF:\n{str(e)}")
    
    def on_resize(self, event):
        """Handle window resize - currently disabled auto-resize for precision"""
        pass  # Keeping 1:1 scaling for accuracy


class TextInputDialog(simpledialog.Dialog):
    """Custom dialog for text input with better styling"""
    
    def __init__(self, parent, title, prompt):
        self.prompt = prompt
        self.result = None
        super().__init__(parent, title)
    
    def body(self, master):
        """Create dialog body"""
        tk.Label(master, text=self.prompt, font=("Arial", 10)).grid(row=0, pady=10, padx=10)
        
        self.text_entry = tk.Entry(master, width=50, font=("Arial", 11))
        self.text_entry.grid(row=1, pady=10, padx=10)
        self.text_entry.focus_set()
        
        return self.text_entry
    
    def apply(self):
        """Process the result"""
        self.result = self.text_entry.get()


def main():
    """Main application entry point"""
    root = tk.Tk()
    
    # Set application icon behavior
    try:
        root.iconbitmap(default='')
    except:
        pass
    
    # Create the application
    app = PDFTextEditor(root)
    
    # Start the main loop
    root.mainloop()


if __name__ == "__main__":
    main()
