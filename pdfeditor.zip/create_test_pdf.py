"""
Create a sample PDF for testing the PDF editor
"""

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch

def create_test_pdf():
    """Create a simple test PDF with multiple pages"""
    filename = "test_document.pdf"
    c = canvas.Canvas(filename, pagesize=letter)
    width, height = letter
    
    # Page 1
    c.setFont("Helvetica-Bold", 24)
    c.drawString(1*inch, height - 1*inch, "Sample PDF Document")
    
    c.setFont("Helvetica", 12)
    c.drawString(1*inch, height - 1.5*inch, "This is a test document for the PDF Editor")
    c.drawString(1*inch, height - 1.8*inch, "Click anywhere on this page to add text!")
    
    # Draw some boxes to show editing areas
    c.rect(1*inch, height - 3*inch, 4*inch, 0.5*inch, stroke=1, fill=0)
    c.drawString(1.1*inch, height - 2.85*inch, "Click here to add text in this box")
    
    c.rect(1*inch, height - 4*inch, 4*inch, 0.5*inch, stroke=1, fill=0)
    c.drawString(1.1*inch, height - 3.85*inch, "Or click here to add different text")
    
    # Add some instructions
    c.setFont("Helvetica-Oblique", 10)
    c.drawString(1*inch, height - 5*inch, "Instructions:")
    c.drawString(1*inch, height - 5.3*inch, "1. Open this PDF in the editor")
    c.drawString(1*inch, height - 5.6*inch, "2. Click anywhere to add custom text")
    c.drawString(1*inch, height - 5.9*inch, "3. Experiment with different font sizes and colors")
    c.drawString(1*inch, height - 6.2*inch, "4. Navigate between pages using the navigation buttons")
    c.drawString(1*inch, height - 6.5*inch, "5. Save your edited PDF when done")
    
    c.showPage()
    
    # Page 2
    c.setFont("Helvetica-Bold", 20)
    c.drawString(1*inch, height - 1*inch, "Page 2 - More Testing Area")
    
    c.setFont("Helvetica", 11)
    c.drawString(1*inch, height - 1.5*inch, "This page has more space for testing")
    c.drawString(1*inch, height - 1.8*inch, "Try adding text with different:")
    c.drawString(1.5*inch, height - 2.1*inch, "• Font sizes (6-72pt)")
    c.drawString(1.5*inch, height - 2.4*inch, "• Colors (use the color picker)")
    c.drawString(1.5*inch, height - 2.7*inch, "• Fonts (Helvetica, Times, Courier, Symbol)")
    
    # Draw a grid for alignment testing
    c.setStrokeColorRGB(0.8, 0.8, 0.8)
    for i in range(1, 8):
        c.line(i*inch, height - 3.5*inch, i*inch, height - 7*inch)
    for i in range(4, 8):
        c.line(1*inch, height - i*inch + 0.5*inch, 7*inch, height - i*inch + 0.5*inch)
    
    c.setStrokeColorRGB(0, 0, 0)
    c.setFont("Helvetica", 9)
    c.drawString(1*inch, height - 7.3*inch, "Grid for precise placement testing")
    
    c.showPage()
    
    # Page 3
    c.setFont("Helvetica-Bold", 20)
    c.drawString(1*inch, height - 1*inch, "Page 3 - Form Fields")
    
    c.setFont("Helvetica", 11)
    
    # Simulate form fields
    fields = [
        ("Name:", height - 2*inch),
        ("Email:", height - 2.8*inch),
        ("Phone:", height - 3.6*inch),
        ("Address:", height - 4.4*inch),
        ("City:", height - 5.2*inch),
        ("Comments:", height - 6*inch),
    ]
    
    for label, y_pos in fields:
        c.drawString(1*inch, y_pos, label)
        c.line(2*inch, y_pos - 3, 6*inch, y_pos - 3)
    
    c.setFont("Helvetica-Oblique", 9)
    c.drawString(1*inch, height - 7*inch, "Use the editor to fill in these form fields!")
    
    # Save the PDF
    c.save()
    print(f"✅ Test PDF created: {filename}")
    return filename

if __name__ == "__main__":
    create_test_pdf()
