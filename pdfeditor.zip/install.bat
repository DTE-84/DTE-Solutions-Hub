@echo off
echo ======================================
echo PDF Editor - Installation Script
echo ======================================
echo.

REM Check Python installation
echo Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python not found. Please install Python 3.7 or higher.
    echo Download from: https://www.python.org/downloads/
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('python --version') do set PYTHON_VERSION=%%i
echo ✅ %PYTHON_VERSION% found
echo.

echo Installing required packages...
echo.

REM Install PyMuPDF
echo Installing PyMuPDF (fitz)...
pip install pymupdf
if %errorlevel% neq 0 (
    echo ❌ Failed to install PyMuPDF
    pause
    exit /b 1
)
echo ✅ PyMuPDF installed successfully
echo.

REM Install Pillow
echo Installing Pillow (PIL)...
pip install pillow
if %errorlevel% neq 0 (
    echo ❌ Failed to install Pillow
    pause
    exit /b 1
)
echo ✅ Pillow installed successfully
echo.

REM Install ReportLab
echo Installing ReportLab (for test PDF creation)...
pip install reportlab
if %errorlevel% neq 0 (
    echo ⚠️  ReportLab installation failed (optional - only needed for test PDF)
) else (
    echo ✅ ReportLab installed successfully
)
echo.

echo ======================================
echo Installation Complete! 🎉
echo ======================================
echo.
echo To run the PDF editor:
echo   python pdf_editor_pro.py
echo.
echo To create a test PDF:
echo   python create_test_pdf.py
echo.
echo See README.md for full documentation
echo.
pause
