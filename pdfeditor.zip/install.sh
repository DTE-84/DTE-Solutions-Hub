#!/bin/bash

echo "======================================"
echo "PDF Editor - Installation Script"
echo "======================================"
echo ""

# Check Python installation
echo "Checking Python installation..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo "✅ $PYTHON_VERSION found"
else
    echo "❌ Python 3 not found. Please install Python 3.7 or higher."
    exit 1
fi

echo ""
echo "Installing required packages..."
echo ""

# Install PyMuPDF
echo "Installing PyMuPDF (fitz)..."
pip install pymupdf --break-system-packages
if [ $? -eq 0 ]; then
    echo "✅ PyMuPDF installed successfully"
else
    echo "❌ Failed to install PyMuPDF"
    exit 1
fi

echo ""

# Install Pillow
echo "Installing Pillow (PIL)..."
pip install pillow --break-system-packages
if [ $? -eq 0 ]; then
    echo "✅ Pillow installed successfully"
else
    echo "❌ Failed to install Pillow"
    exit 1
fi

echo ""

# Install reportlab for test PDF creation
echo "Installing ReportLab (for test PDF creation)..."
pip install reportlab --break-system-packages
if [ $? -eq 0 ]; then
    echo "✅ ReportLab installed successfully"
else
    echo "⚠️  ReportLab installation failed (optional - only needed for test PDF)"
fi

echo ""
echo "======================================"
echo "Installation Complete! 🎉"
echo "======================================"
echo ""
echo "To run the PDF editor:"
echo "  python3 pdf_editor_pro.py"
echo ""
echo "To create a test PDF:"
echo "  python3 create_test_pdf.py"
echo ""
echo "See README.md for full documentation"
echo ""
